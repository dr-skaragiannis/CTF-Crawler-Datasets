sudo -l
exit
/usr/sbin/useradd username
python -c 'import os; os.system("/bin/bash")'
exit
sudo python -c 'import os; os.system("/bin/bash")'
exit
python -c 'import os; os.system("/bin/bash")'
exit
